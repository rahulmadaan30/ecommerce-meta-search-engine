# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render
from django.http import HttpResponse
from .forms import *
from .models import *
from .signals import *
from django.views.generic import ListView, DetailView
from Price_compare import compare_prices
from project.mixins import ObjectViewMixin
from django.http import Http404
from django.shortcuts import get_object_or_404, render

# Create your views here.
def contact(request):

    if(request.method == 'POST'):
        form = ContactForm(request.POST)
        if form.is_valid():
            prodname = form.cleaned_data['Product']
            m_or_others = form.cleaned_data['answer']
            #print(prodname,m_or_others)
            compare_prices(prodname,m_or_others)

    form = ContactForm()
    return render(request, 'page.html', {'form': form})

def index(request):
        return render(request, 'index.html')

def display_electronics(request):
    items = Electronics.objects.all()
    context = {
         'items' : items,
    }
    return render(request, 'index.html', context)

def display_mobiles(request):
    items = Mobile.objects.all()
    context = {
         'items' : items,
    }
    return render(request, 'index.html', context)

def nex(request):
        return render(request,'index.html')

class PostList(ListView):
    model = Mobile

    def get_object(self):
        mobile_pk = self.kwargs.get("pk")
        if mobile_pk:
            mobile_query = Mobile.objects.filter(pk=pk)
            if mobile_query.exists():
                mobile_object = mobile_query.first()
                view, created = View.objects.get_or_create(
                        user=self.request.user,
                        post=post_object
                    )
                if view:
                    view.views_count +=1
                    view.save()

                return mobile_object
        return Http404

class PostDetail(DetailView):
    model = Mobile


from .models import Review, Wine


def review_list(request):
    latest_review_list = Review.objects.order_by('-pub_date')[:9]
    context = {'latest_review_list':latest_review_list}
    return render(request, 'review_list.html', context)


def review_detail(request, review_id):
    review = get_object_or_404(Review, pk=review_id)
    return render(request, 'review_detail.html', {'review': review})


def phone_list(request):
    phone_list = Phone.objects.order_by('-name')
    context = {'phone_list':phone_list}
    return render(request, 'phone_list.html', context)


def phone_detail(request, phone_id):
    phone = get_object_or_404(Phone, pk=phone_id)
    return render(request, 'phone_detail.html', {'phone': phone})    
