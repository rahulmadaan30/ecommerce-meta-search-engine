# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.shortcuts import render
from django.http import HttpResponse
from .forms import *
from .models import *
from django.views.generic import ListView, DetailView
from Price_compare import compare_prices
from project.mixins import ObjectViewMixin

# Create your views here.
def contact(request):

    if(request.method == 'POST'):
        form = ContactForm(request.POST)
        if form.is_valid():
            prodname = form.cleaned_data['Product']
            m_or_others = form.cleaned_data['answer']
            #print(prodname,m_or_others)
            compare_prices(prodname,m_or_others)

    form = ContactForm()
    return render(request, 'page.html', {'form': form})

def index(request):
        return render(request, 'index.html')

def display_electronics(request):
    items = Electronics.objects.all()
    context = {
         'items' : items,
    }
    return render(request, 'index.html', context)

def display_mobiles(request):
    items = Mobile.objects.all()
    context = {
         'items' : items,
    }
    return render(request, 'index.html', context)

def nex(request):
        return render(request,'index.html')

class PostList(ListView):
    model = Device

class PostDetail(ObjectViewMixin, DetailView):
    model = Device
