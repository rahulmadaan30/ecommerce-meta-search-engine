from django import forms
from django.utils.safestring import mark_safe


class ContactForm(forms.Form):

    CHOICES= [
    (1, 'Electronics'),
    (2, '  Mobiles    '),
    ]
    Product = forms.CharField(max_length = 100,label='',widget=forms.TextInput(attrs={'placeholder': 'Enter The Product Name'}))
    answer = forms.CharField(label ='',
                            widget=forms.Select(choices=CHOICES))    
