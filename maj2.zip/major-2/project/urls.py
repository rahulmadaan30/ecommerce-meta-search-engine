from django.conf.urls import url
from .views import *
from . import views

urlpatterns = [
    url(r'^$', views.contact ,name='page'),
    url(r'^$', views.index ,name='index'),

    url(r'^display_electronic$', display_electronics, name='display_electronics'),
    url(r'^display_mobile$', display_mobiles, name='display_mobiles'),
    url(r'^display_electronic$', ListView.as_view(), name='list'),
    url(r'^display_electronic$', DetailView.as_view(), name='detail'),


     url(r'^$', views.review_list, name='review_list'),
    # ex: /review/5/
    url(r'^review/(?P<review_id>[0-9]+)/$', views.review_detail, name='review_detail'),
    # ex: /wine/
    url(r'^phone$', views.phone_list, name='phone_list'),
    # ex: /wine/5/
    url(r'^phone/(?P<phone_id>[0-9]+)/$', views.phone_detail, name='phone_detail'),

]
