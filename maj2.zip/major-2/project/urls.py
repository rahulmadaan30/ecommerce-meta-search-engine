from django.conf.urls import url
from . import views
from .views import *

urlpatterns = [
    url(r'^$', views.contact ,name='page'),
    url(r'^$', views.index ,name='index'),

    url(r'^display_electronic$', display_electronics, name='display_electronics'),
    url(r'^display_mobile$', display_mobiles, name='display_mobiles'),
]
