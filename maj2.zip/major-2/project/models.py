# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Device(models.Model):

    name = models.CharField(max_length=100, blank=False)
    flipkart = models.IntegerField(default = 0)
    snapdeal = models.IntegerField(default = 0)
    infibeam = models.IntegerField(default = 0)
    croma = models.IntegerField(default = 0)
    shopclues = models.IntegerField(default = 0)
    paytmmall = models.IntegerField(default = 0)

    class Meta:
        abstract = True

    def __str__(self):
        return 'Name : {0} Flipkart : {1} Snapdeal : {2} Infibeam : {3} Croma : {4} Shopclues : {5} Paytmmall : {6}'.format(self.name, self.flipkart, self.snapdeal, self.infibeam, self.croma, self.shopclues, self.paytmmall)

class Electronics(Device):
    pass

class Mobile(Device):
    pass
