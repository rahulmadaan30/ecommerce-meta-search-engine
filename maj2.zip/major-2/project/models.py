# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey
from django.conf import settings
from .signals import object_viewed_signal

# Create your models here.

User = settings.AUTH_USER_MODEL

class History(models.Model):
    user           = models.ForeignKey(User, on_delete=models.CASCADE)
    content_type   = models.ForeignKey(ContentType, on_delete=models.SET_NULL, null=True)
    object_id      = models.PositiveIntegerField()
    content_object = GenericForeignKey()
    viewed_on      = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return str(self.content_type)

    class Meta:
        verbose_name_plural = "Histories"

def object_viewed_reciever(sender, instance, request, *args, **kwargs):
    new_history = History.objects.create(
    user = request.user,
    content_type = ContentType.objects.get_for_model(sender),
    object_id  = instance.id,
    )

object_viewed_signal.connect(object_viewed_reciever)

class Device(models.Model):

    name = models.CharField(max_length=100, blank=False)
    flipkart = models.FloatField(default = 0)
    snapdeal = models.FloatField(default = 0)
    infibeam = models.FloatField(default = 0)
    croma = models.FloatField(default = 0)
    shopclues = models.FloatField(default = 0)
    paytmmall = models.FloatField(default = 0)

    class Meta:
        abstract = True

    def __str__(self):
        return 'Name : {0} Flipkart : {1} Snapdeal : {2} Infibeam : {3} Croma : {4} Shopclues : {5} Paytmmall : {6}'.format(self.name, self.flipkart, self.snapdeal, self.infibeam, self.croma, self.shopclues, self.paytmmall)

class Electronics(Device):
    pass

class Mobile(Device):
    pass

class ObjectViewed(models.Model):
    user           = models.ForeignKey(User, blank=True, null=True) #user instace created
    ip_address     = models.CharField(max_length=220, blank=True, null=True) #ip field
    content_type   = models.ForeignKey(ContentType) #device
    object_id      = models.PositiveIntegerField() #user id
    content_object = GenericForeignKey('content_type', 'object_id') # create device instace
    timestamp      = models.DateTimeField(auto_now_add=True)


    def __str__(self):
         return "%s viewed on %s" %(self.content_object, self.timestamp)

    class Meta:
        ordering = ['-timestamp']
        verbose_name = 'Object viewed'
        verbose_name_plural = 'Objects viewed'
