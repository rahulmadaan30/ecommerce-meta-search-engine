# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import *
from import_export.admin import ImportExportModelAdmin

# Register your models here.
@admin.register(Electronics, Mobile)
class ViewAdmin(ImportExportModelAdmin):
    model = Review
    list_display = ('phone', 'rating', 'user_name', 'comment', 'pub_date')
    list_filter = ['pub_date', 'user_name']
    search_fields = ['comment']

admin.site.register(Phone)

admin.site.register(Review, ReviewAdmin)

admin.site.register(History)

admin.site.register(ObjectViewed)

admin.site.register(View)
