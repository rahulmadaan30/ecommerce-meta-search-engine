from bs4 import BeautifulSoup
import requests
import warnings
from prettytable import PrettyTable

warnings.filterwarnings("ignore")

def func_flipkart(product_list,Prices,Names,Ratings):
    first_url = 'https://www.flipkart.com/search?q='
    end_url = '&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=on&as=off'
    first_url = first_url + product_list[0]
    products = product_list[1:]
    for item in products:
        first_url = first_url + '%20' + item
    #print(first_url)
    url = first_url + end_url
    #print(url)
    htt = 'https://www.flipkart.com'
    source = requests.get(url)
    soup = BeautifulSoup(source.content)
    containers = soup.findAll("div", {"class" : "_3O0U0u"})
    #print(len(containers))
    #print(soup.prettify(containers[0]))
    lists_of_items = containers
    #contain = lists_of_items[1]
    x = len(lists_of_items)
    y=30
    if(x<y):
        index = x
    else:
        index = y
    for i in range(0,index):
        contain = lists_of_items[i]
        #Names.append(contain.div.img["alt"])
        src = contain.div.div.a["href"]
        src = htt+src
        source = requests.get(src)
        sou = BeautifulSoup(source.content)
        ff = sou.find("span", {"class" : "_35KyD6"})
        Names.append(ff.text)
        price = contain.findAll("div", {"class" : "_1vC4OE"})
        st = price[0].text
        pr = st[1:]
        Prices.append(pr)
        rate = contain.find("div", {"class" : "hGSR34 _2beYZw"})
        if(rate != None):
            st = rate.encode('ascii')
            if(st[29] == '.'):
                Ratings.append(float(st[28:31]))
            else:
                Ratings.append(float(st[28:29]))
        else:
            Ratings.append('No Rating')
    return index

