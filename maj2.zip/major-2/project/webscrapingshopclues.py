from bs4 import BeautifulSoup
import requests
import warnings
from prettytable import PrettyTable

warnings.filterwarnings("ignore")

def func_shopclues(product_list,Names,Prices):
    first_url = 'https://www.shopclues.com/search?q='
    end_url = '&sc_z=1111&z=1&count=10'
    first_url = first_url + product_list[0]
    products = product_list[1:]
    for item in products:
        first_url = first_url + '%20' + item

    url = first_url + end_url

    source = requests.get(url)
    soup = BeautifulSoup(source.content)
    containers = soup.findAll("div", {"class" : "column col3 search_blocks"})

    lists_of_items = containers
    x = len(lists_of_items)
    print(x)
    y=30
    if(x<y):
        index = x
    else:
        index = y

    for i in range(0,index):
        contain = lists_of_items[i]
        Names.append(contain.a.div.img["alt"])
        price = contain.find("span", {"class" : "p_price"})

        st = price.text
        final_price = st.encode('ascii')
        final_price = final_price[3:]
        final_price = float(final_price)
        Prices.append(final_price)

    return index

