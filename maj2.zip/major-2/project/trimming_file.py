from nltk.tokenize import RegexpTokenizer
import xlrd
import xlsxwriter

def check(Name1,Name2):
    tokenizer = RegexpTokenizer(r'\w+')
    Name1 = Name1.lower()
    nam1 = tokenizer.tokenize(Name1)
    Name2 = Name2.encode('utf-8')
    Name2 = Name2.lower()
    nam2 = tokenizer.tokenize(Name2)
    n1 = len(nam1)
    count=0
    for i in range(0,n1):
        if(nam1[i] in nam2):
            count+=1
    if(count == n1):
        return True
    else:
        return False
    
    
    
def func_analyse(prod_name):
    workbook = xlsxwriter.Workbook('compare_final_list.xlsx')
    worksheet = workbook.add_worksheet()
    worksheet.write(0,0,'id')
    worksheet.write(0,1,'name')
    worksheet.write(0,2,'flipkart')
    worksheet.write(0,3,'snapdeal')
    worksheet.write(0,4,'infibeam')
    worksheet.write(0,5,'croma')
    worksheet.write(0,6,'shopclues')
    worksheet.write(0,7,'paytmmall')
    k=1
    x=1
    wb = xlrd.open_workbook('compare.xlsx')
    sheet = wb.sheet_by_index(0)
    sheet.cell_value(0,0)
    for i in range(1,sheet.nrows):
        if(check(prod_name,sheet.cell_value(i,1))==True):
            worksheet.write(k,0,x)
            x+=1
            worksheet.write(k,1,sheet.cell_value(i,1))
            worksheet.write(k,2,sheet.cell_value(i,2))
            worksheet.write(k,3,sheet.cell_value(i,3))
            worksheet.write(k,4,sheet.cell_value(i,4))
            worksheet.write(k,5,sheet.cell_value(i,5))
            worksheet.write(k,6,sheet.cell_value(i,6))
            worksheet.write(k,7,sheet.cell_value(i,7))
            k+=1

    workbook.close()
    print("work done")
        
#func_analyse('iphone 8')
    
