from bs4 import BeautifulSoup
import requests
import warnings
from prettytable import PrettyTable
import sys
reload(sys)
sys.setdefaultencoding('utf8')

warnings.filterwarnings("ignore")

def func_snapdeal(product_list,Names,Prices):
    first_url = 'https://www.snapdeal.com/search?keyword='
    end_url = '&santizedKeyword=iphone+se&catId=0&categoryId=0&suggested=false&vertical=p&noOfResults=20&clickSrc=go_header&lastKeyword=&prodCatId=&changeBackToAll=false&foundInAll=false&categoryIdSearched=&cityPageUrl=&categoryUrl=&url=&utmContent=&dealDetail=&sort=rlvncy'
    first_url = first_url + product_list[0]
    products = product_list[1:]
    for item in products:
        first_url = first_url + '%20' + item
    #print(first_url)
    url = first_url + end_url
    #print(url)

    source = requests.get(url)
    soup = BeautifulSoup(source.content)
    containers = soup.findAll("div", {"class" : "product-tuple-description "})

    #print(len(containers))
    #print(soup.prettify(containers[0]))
    lists_of_items = containers
    x = len(lists_of_items)
    y = 30
    if(x<y):
        index = x
    else:
        index = y
    for i in range(0,index):
        contain = lists_of_items[i]
        Names.append(contain.div.a.p["title"])

        price = contain.findAll("span", {"class" : "lfloat product-price"})
        #print(price[0].text)
        st = price[0].text
        pr = st[3:]
        pt = pr.encode('utf-8')
        pt = pt.replace(',','')
        Prices.append(pt)

    return index
    
