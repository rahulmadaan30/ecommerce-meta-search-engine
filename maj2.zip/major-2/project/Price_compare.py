from webscrapingflipkart import func_flipkart
from webscrapingsnapdeal import func_snapdeal
from webscrapinginfibeam import func_infibeam
from webscrapingshopclues import func_shopclues
from webscrapingcroma import func_croma
from webscrapingpaytm import func_paytm
from example import func_to_combine
from example import func_to_combine_next
import warnings
from prettytable import PrettyTable
from nltk.tokenize import RegexpTokenizer
#import csv
import xlsxwriter

def compare_prices(name,a):
    warnings.filterwarnings("ignore")
    product = name
    product_list = product.split(' ')
    m_or_others = a
    Prices_flipkart = []
    Names_flipkart = []
    Ratings_flipkart = []

    index_f = func_flipkart(product_list,Prices_flipkart,Names_flipkart,Ratings_flipkart)

    table = PrettyTable(['Product Name', 'Price','Ratings'])
    for i in range(0,index_f):
        table.add_row([Names_flipkart[i],Prices_flipkart[i],Ratings_flipkart[i]])

    print(table.get_string(title="Flipkart"))

    Prices_snapdeal = []
    Names_snapdeal = []

    index_s = func_snapdeal(product_list,Names_snapdeal,Prices_snapdeal)

    table = PrettyTable(['Product Name', 'Price'])
    for i in range(0,index_s):
        table.add_row([Names_snapdeal[i],Prices_snapdeal[i]])

    print(table.get_string(title="Snapdeal"))

    Prices_infibeam = []
    Names_infibeam = []

    index_i = func_infibeam(product_list,Names_infibeam,Prices_infibeam)

    table = PrettyTable(['Product Name', 'Prices'])
    for i in range(0,index_i):
        table.add_row([Names_infibeam[i],Prices_infibeam[i]])

    print(table.get_string(title="Infibeam"))

    Prices_croma = []
    Names_croma = []

    index_c = func_croma(product_list,Names_croma,Prices_croma)

    table = PrettyTable(['Product Name', 'Price'])
    for i in range(0,index_c):
        table.add_row([Names_croma[i],Prices_croma[i]])

    print(table.get_string(title="Croma"))

    Prices_shopclues = []
    Names_shopclues = []

    index_shop = func_shopclues(product_list,Names_shopclues,Prices_shopclues)

    table = PrettyTable(['Product Name', 'Price'])
    for i in range(0,index_shop):
        table.add_row([Names_shopclues[i],Prices_shopclues[i]])

    print(table.get_string(title="Shopclues"))

    Prices_paytm = []
    Names_paytm = []

    index_paytm = func_paytm(product_list,Prices_paytm,Names_paytm)

    table = PrettyTable(['Product Name', 'Price'])
    for i in range(0,index_paytm):
        table.add_row([Names_paytm[i],Prices_paytm[i]])

    print(table.get_string(title="Paytm mall"))


    final_table_Name = []
    final_table_Price_flipkart = []
    final_table_Price_snapdeal = []
    final_table_Price_infibeam = []
    final_table_Price_croma = []
    final_table_Price_shopclues = []
    final_table_Price_paytm = []
    func_to_combine(m_or_others,Names_flipkart,Names_snapdeal,Prices_flipkart,Prices_snapdeal,final_table_Name,final_table_Price_flipkart,final_table_Price_snapdeal,index_f,index_s)
    index = len(final_table_Name)
    func_to_combine_next(m_or_others,Names_infibeam,Prices_infibeam,final_table_Name,final_table_Price_infibeam,index_i,index)
    index_i = len(Names_infibeam)
    for i in range(0,index_i):
        final_table_Name.append(Names_infibeam[i])
        final_table_Price_flipkart.append(0)
        final_table_Price_snapdeal.append(0)
        final_table_Price_infibeam.append(Prices_infibeam[i])

    index = len(final_table_Name)
    func_to_combine_next(m_or_others,Names_croma,Prices_croma,final_table_Name,final_table_Price_croma,index_c,index)
    index_c = len(Names_croma)
    for i in range(0,index_c):
        final_table_Name.append(Names_croma[i])
        final_table_Price_flipkart.append(0)
        final_table_Price_snapdeal.append(0)
        final_table_Price_infibeam.append(0)
        final_table_Price_croma.append(Prices_croma[i])

    index = len(final_table_Name)
    func_to_combine_next(m_or_others,Names_shopclues,Prices_shopclues,final_table_Name,final_table_Price_shopclues,index_shop,index)
    index_shop = len(Names_shopclues)
    for i in range(0,index_shop):
        final_table_Name.append(Names_shopclues[i])
        final_table_Price_flipkart.append(0)
        final_table_Price_snapdeal.append(0)
        final_table_Price_infibeam.append(0)
        final_table_Price_croma.append(0)
        final_table_Price_shopclues.append(Prices_shopclues[i])

    index = len(final_table_Name)
    func_to_combine_next(m_or_others,Names_paytm,Prices_paytm,final_table_Name,final_table_Price_paytm,index_paytm,index)
    index_paytm = len(Names_paytm)
    for i in range(0,index_paytm):
        final_table_Name.append(Names_paytm[i])
        final_table_Price_flipkart.append(0)
        final_table_Price_snapdeal.append(0)
        final_table_Price_infibeam.append(0)
        final_table_Price_croma.append(0)
        final_table_Price_shopclues.append(0)
        final_table_Price_paytm.append(Prices_paytm[i])


    index = len(final_table_Name)

    table = PrettyTable(['Product Name', 'Flipkart Price', 'Snapdeal Price', 'Infibeam Price', 'Croma Price', 'Shopclues Price', 'Paytmmall Price'])
    for i in range(0,index):
        table.add_row([final_table_Name[i],final_table_Price_flipkart[i],final_table_Price_snapdeal[i],final_table_Price_infibeam[i],final_table_Price_croma[i],final_table_Price_shopclues[i],final_table_Price_paytm[i]])

    print(table.get_string(title="Compare List"))

    #with open('compare.csv', mode='w') as employee_file:
    #    writer = csv.writer(employee_file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    #    writer.writerow(['Product Name','Flipkart Price','Snapdeal Price', 'Infibeam Price','Croma Price','Shopclues Price', 'Paytmmall Price'])
    #    for i in range(0,index):
    #        writer.writerow([final_table_Name[i].encode('utf-8'),final_table_Price_flipkart[i],final_table_Price_snapdeal[i],final_table_Price_infibeam[i],final_table_Price_croma[i],final_table_Price_shopclues[i],final_table_Price_paytm[i]])

    workbook = xlsxwriter.Workbook('compare.xlsx')
    worksheet = workbook.add_worksheet()
    worksheet.write(0,0,'id')
    worksheet.write(0,1,'name')
    worksheet.write(0,2,'flipkart')
    worksheet.write(0,3,'snapdeal')
    worksheet.write(0,4,'infibeam')
    worksheet.write(0,5,'croma')
    worksheet.write(0,6,'shopclues')
    worksheet.write(0,7,'paytmmall')

    k=1
    for i in range(0,index):
        x = final_table_Name[i]
        worksheet.write(i+1,0,k)
        k = k+1
        worksheet.write(i+1,1,x)
        worksheet.write(i+1,2,final_table_Price_flipkart[i])
        worksheet.write(i+1,3,final_table_Price_snapdeal[i])
        worksheet.write(i+1,4,final_table_Price_infibeam[i])
        worksheet.write(i+1,5,final_table_Price_croma[i])
        worksheet.write(i+1,6,final_table_Price_shopclues[i])
        worksheet.write(i+1,7,final_table_Price_paytm[i])

    workbook.close()
