from bs4 import BeautifulSoup
import requests
import warnings
from prettytable import PrettyTable

warnings.filterwarnings("ignore")

def func_paytm(product_list,Prices,Names):
    first_url = 'https://paytmmall.com/shop/search?q='
    end_url = '&from=organic&child_site_id=6'
    first_url = first_url + product_list[0]
    products = product_list[1:]
    for item in products:
        first_url = first_url + '%20' + item
    #print(first_url)
    url = first_url + end_url
    #print(url)
    htt = 'https://www.flipkart.com'
    source = requests.get(url)
    soup = BeautifulSoup(source.content)
    containers = soup.findAll("div", {"class" : "_2i1r"})
    #print(len(containers))
    #print(soup.prettify(containers[0]))
    lists_of_items = containers
    #contain = lists_of_items[1]
    x = len(lists_of_items)
    y=30
    if(x<y):
        index = x
    else:
        index = y
    for i in range(0,index):
        contain = lists_of_items[i]
        Names.append(contain.div.a.div.img["alt"])
        price = contain.find("div", {"class" : "_1kMS"})
        st = price.span
        pr = st.text
        Prices.append(pr)

    return index

