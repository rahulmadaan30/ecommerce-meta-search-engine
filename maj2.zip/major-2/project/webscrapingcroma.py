from bs4 import BeautifulSoup
import requests
import warnings
from prettytable import PrettyTable

warnings.filterwarnings("ignore")


def func_croma(product_list,Names,Prices):
    first_url = 'https://www.croma.com/search/?text='
    first_url = first_url + product_list[0]
    products = product_list[1:]
    for item in products:
        first_url = first_url + '+' + item
    #print(first_url)
    url = first_url
    #print(url)
    source = requests.get(url)
    soup = BeautifulSoup(source.content)
    containers = soup.findAll("div", {"style" : " margin-right: 0;"})

    #print(len(containers))
    #print(soup.prettify(containers[0]))
    lists_of_items = containers

    x = len(lists_of_items)
    y=30
    if(x<y):
        index = x
    else:
        index = y
    for i in range(0,index):
        contain = lists_of_items[i]
        nam = contain.a.h2
        Names.append(nam.text)
        price = contain.find("span", {"class" : "pdpPrice"})
        st = price.text
        pr = st[1:]
        pr = pr[:-1]
        Prices.append(pr.encode('ascii'))

    return index


