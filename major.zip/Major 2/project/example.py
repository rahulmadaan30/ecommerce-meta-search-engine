from nltk.tokenize import RegexpTokenizer

def validateString(s):
    letter_flag = False
    number_flag = False
    for i in s:
        if i.isalpha():
            letter_flag = True
        if i.isdigit():
            number_flag = True
    return letter_flag and number_flag

def checkforothers(Name1,Name2):
    tokenizer = RegexpTokenizer(r'\w+')
    id1 = 'abcd'
    id2 = 'xyz'
    nam1 = tokenizer.tokenize(Name1)
    nam2 = tokenizer.tokenize(Name2)
    for i in nam1:
        if(validateString(i)):
            id1 = i
            break
    for i in nam2:
        if(validateString(i)):
            id2 = i
            break
    if(id1 == id2):
        return True
    else:
        return False

def checkformobiles(Name1,Name2):
    tokenizer = RegexpTokenizer(r'\w+')
    nam1 = tokenizer.tokenize(Name1)
    nam2 = tokenizer.tokenize(Name2)
    n1 = len(nam1)
    n2 = len(nam2)
    count = 0
    for i in range(0,n1):
        if(nam1[i] in nam2):
            count+=1
    if(count == n1):
        count=0
        for i in range(0,n2):
            if(nam2[i] in nam1):
                count+=1
        if(count==n2):
            return True
        else:
            return False
    else:
        return False

def func_to_combine(m_or_others,Names1,Names2,Prices1,Prices2,final_table_Name,final_table_Price_1,final_table_Price_2,index1,index2):
    for i in range(0,index1):
        ch=0
        for j in range(0,index2):
            if(m_or_others == '1'):
                b=checkforothers(Names1[i],Names2[j])
            else:
                b=checkformobiles(Names1[i],Names2[j])
            if(b==True):
                ch=1
                final_table_Name.append(Names1[i])
                final_table_Price_1.append(Prices1[i])
                final_table_Price_2.append(Prices2[j])
                Names2.pop(j)
                Prices2.pop(j)
                index2 = len(Names2)
                break
        if(ch==0):
            final_table_Name.append(Names1[i])
            final_table_Price_1.append(Prices1[i])
            final_table_Price_2.append(0)

    index_s = len(Names2)
    for i in range(0,index_s):
        final_table_Price_2.append(Prices2[i])
        final_table_Name.append(Names2[i])
        final_table_Price_1.append(0)

def func_to_combine_next(m_or_others,Names2,Prices2,final_table_Name,final_table_Price_infibeam,index_i,index):
    
    for i in range(0,index):
        ch=0
        for j in range(0,index_i):
            if(m_or_others=='1'):
                b=checkforothers(final_table_Name[i],Names2[j])
            else:
                b=checkformobiles(final_table_Name[i],Names2[j])
            if(b==True):
                ch=1
                final_table_Price_infibeam.append(Prices2[j])
                Names2.pop(j)
                Prices2.pop(j)
                index_i = len(Names2)
                break
        if(ch==0):
            final_table_Price_infibeam.append(0)
