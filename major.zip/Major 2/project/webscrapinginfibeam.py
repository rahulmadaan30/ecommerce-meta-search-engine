from bs4 import BeautifulSoup
import requests
import warnings
from prettytable import PrettyTable
import sys
reload(sys)
sys.setdefaultencoding('utf8')

warnings.filterwarnings("ignore")

def func_infibeam(product_list,Names,Prices):
    first_url = 'https://www.infibeam.com/search?q='
    end_url = '&us=nbc'
    first_url = first_url + product_list[0]
    products = product_list[1:]
    for item in products:
        first_url = first_url + '%20' + item
    #print(first_url)
    url = first_url + end_url
    #print(url)
    source = requests.get(url)
    soup = BeautifulSoup(source.content)
    containers = soup.findAll("div", {"class" : " col-md-3 col-sm-6 col-xs-12 search-icon flex-item"})

    print(len(containers))

    lists_of_items = containers
    x = len(lists_of_items)
    y=30
    if(x<y):
        index = x
    else:
        index = y
    for i in range(0,index):
        contain = lists_of_items[i]

        price = contain.find("span", {"class" : "final-price"})
        #print(price)
        st = price.text
        pr = st[3:]
        pt = pr.encode('utf-8')
        if(not('Not' in pt)):
            pt = pt.replace(',','')
            Prices.append(pt)
            Names.append(contain.div.div.a.picture.img["alt"])
    index = len(Prices)
    return index
